# SKILL-SCREEN-EXPANSION.md — Modular Screen Expansion Animation System
**Expertise Level:** Expert  
**Domain:** CSS transforms, Framer Motion, Web Animations API, 60fps mechanical UI  
**Context:** Hardware module panels that physically unfold, slide, and slot from a parent device unit

---

## 1. Core Concept

The screen expansion system simulates physical hardware modules being connected to a primary device unit in real time. Each module has:

- A **resting state** (hidden behind or inside the primary unit)
- A **deploy animation** (unfold, slide, or slot into position)
- An **active state** (fully extended, locked in position, interactive)
- A **sleep state** (retracted but indicator visible)

The primary unit is a fixed coordinate anchor. All modules are positioned absolutely relative to a **device canvas** — a full-viewport coordinate space that defines where each module physically belongs.

---

## 2. Coordinate System

```
┌─────────────────────────────────────────────────┐
│                 DEVICE CANVAS                   │
│           (position: relative)                  │
│                                                 │
│          ┌──────────────────┐                   │
│          │   MOD-TIMELINE   │ (above primary)   │
│          └──────────────────┘                   │
│  ┌───┐   ┌──────────────────┐   ┌──────────┐   │
│  │FIL│   │   MOD-PRIMARY    │   │  COMMS   │   │
│  │ES │   │   (ANCHOR)       │   │          │   │
│  └───┘   └──────────────────┘   └──────────┘   │
│          ┌──────────────────┐                   │
│          │  MOD-RESOURCE    │ (below primary)   │
│          └──────────────────┘                   │
└─────────────────────────────────────────────────┘
```

```css
.device-canvas {
  position: relative;
  width: 100vw;
  height: 100vh;
  overflow: hidden; /* clips pre-deployed modules */
}

.mod-primary {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  /* This is the anchor. All other modules position relative to it. */
  z-index: 10;
}
```

Use CSS custom properties to share primary unit dimensions:
```javascript
// Set on mount
const primary = document.querySelector('.mod-primary');
const rect = primary.getBoundingClientRect();
document.documentElement.style.setProperty('--primary-x', `${rect.left}px`);
document.documentElement.style.setProperty('--primary-y', `${rect.top}px`);
document.documentElement.style.setProperty('--primary-w', `${rect.width}px`);
document.documentElement.style.setProperty('--primary-h', `${rect.height}px`);
```

---

## 3. Module Origin Points

Each module has a defined **rest position** (where it hides before deployment) and **active position** (where it locks when deployed).

| Module | Rest Origin | Active Position | Direction Vector |
|---|---|---|---|
| `MOD-TIMELINE` | Behind primary top edge | Above primary, gap 8px | `translateY(-100%)` → `translateY(0)` |
| `MOD-FILES` | Behind primary left edge | Left of primary, gap 8px | `translateX(-100%)` → `translateX(0)` |
| `MOD-COMMS` | Behind primary right edge | Right of primary, gap 8px | `translateX(100%)` → `translateX(0)` |
| `MOD-APPROVALS` | Behind primary, top-right | Top-right diagonal slot | Multi-axis |
| `MOD-LEADERBOARD` | Below MOD-COMMS | Stacked right | `translateY(100%)` → `translateY(0)` |
| `MOD-RESOURCE` | Behind primary bottom | Below primary, gap 8px | `translateY(100%)` → `translateY(0)` |

---

## 4. Deployment Animation Patterns

### 4.1 Pattern A — Linear Slide (FILES, COMMS, RESOURCE, TIMELINE)

The module slides in from behind the primary unit along a single axis.

```css
.module {
  position: absolute;
  transform-origin: center center;
  /* Start state handled by JS class toggle */
}

.module[data-state="dormant"] {
  opacity: 0;
  pointer-events: none;
}

.module[data-state="deploying"],
.module[data-state="active"] {
  opacity: 1;
  pointer-events: all;
}
```

```javascript
// Framer Motion approach (recommended for React)
import { motion, AnimatePresence } from 'framer-motion';

const slideVariants = {
  dormant: { x: '-100%', opacity: 0 },
  deploying: { 
    x: 0, 
    opacity: 1,
    transition: {
      duration: 0.7,
      ease: [0.25, 0, 0, 1], // mechanical snap
    }
  },
  active: { x: 0, opacity: 1 },
  sleeping: { x: '-90%', opacity: 0.3 }
};

<AnimatePresence>
  {isActive && (
    <motion.div
      className="module mod-files"
      variants={slideVariants}
      initial="dormant"
      animate="deploying"
      exit="dormant"
    />
  )}
</AnimatePresence>
```

### 4.2 Pattern B — Unfold (TIMELINE — top expansion)

The module "unfolds" from behind the top of the primary unit — like a physical flap hinging open.

```javascript
const unfoldVariants = {
  dormant: { 
    scaleY: 0, 
    y: '50%',     // starts at primary's centre
    opacity: 0,
    transformOrigin: 'bottom center'
  },
  deploying: {
    scaleY: 1,
    y: 0,
    opacity: 1,
    transition: {
      duration: 0.8,
      ease: [0.25, 0, 0, 1],
      opacity: { duration: 0.3 }
    }
  }
};
```

### 4.3 Pattern C — Slot + Lock (all modules — final frame)

All deployments end with a **mechanical lock**: a brief overshoot + snap back that simulates physical latching.

```javascript
// Add this to all deploy transitions:
const deployTransition = {
  duration: 0.7,
  ease: [0.25, 0, 0, 1],
  // Overshoot simulation:
  // Use spring for the lock snap on final frame
};

// Or with spring:
const lockSnap = {
  type: 'spring',
  stiffness: 600,
  damping: 30,
  mass: 0.8
};

// Pattern: ease into position, then spring-snap the last 5%
// Achieved by chaining two animations:
async function deployWithLock(element, targetPos) {
  // Phase 1: slide to near-final position
  await element.animate([
    { transform: 'translateX(-100%)' },
    { transform: 'translateX(4px)' }  // slight overshoot
  ], {
    duration: 600,
    easing: 'cubic-bezier(0.25, 0, 0, 1)',
    fill: 'forwards'
  }).finished;
  
  // Phase 2: snap back (lock)
  await element.animate([
    { transform: 'translateX(4px)' },
    { transform: 'translateX(0)' }
  ], {
    duration: 80,
    easing: 'cubic-bezier(0.25, 0, 0, 1)',
    fill: 'forwards'
  }).finished;
  
  // Phase 3: indicator light on
  element.querySelector('.indicator-light')?.classList.add('active');
}
```

### 4.4 Pattern D — Magnetic Snap (connection indicator)

When a module slots into position, a brief visual connection signal appears at the junction point:

```css
.module-connector {
  position: absolute;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--hw-blush);
  opacity: 0;
  transition: opacity 0.1s;
}

.module-connector.snapped {
  opacity: 1;
  animation: connector-pulse 0.4s ease-out forwards;
}

@keyframes connector-pulse {
  0%   { transform: scale(1); opacity: 1; }
  50%  { transform: scale(2); opacity: 0.6; }
  100% { transform: scale(1); opacity: 1; }
}
```

---

## 5. Z-Depth & Layering

Modules must stack correctly as if they are physical layers:

```css
/* Z-depth stack — higher number = closer to viewer */
.mod-primary      { z-index: 10; }
.mod-timeline     { z-index: 8;  } /* behind primary top edge */
.mod-files        { z-index: 8;  }
.mod-comms        { z-index: 8;  }
.mod-approvals    { z-index: 9;  } /* slightly in front during deploy */
.mod-leaderboard  { z-index: 7;  }
.mod-resource     { z-index: 8;  }

/* During deployment: temporarily elevate */
.module.deploying { z-index: 15; }
.module.active    { z-index: 8;  } /* settle back */
```

Shadow to simulate depth:
```css
.module {
  box-shadow: 
    4px 4px 12px rgba(0, 0, 0, 0.4),
    -2px 0 8px rgba(0, 0, 0, 0.2);
}
.mod-primary {
  box-shadow: 
    0 8px 24px rgba(0, 0, 0, 0.5),
    0 2px 6px rgba(0, 0, 0, 0.3);
}
```

---

## 6. Module State Machine

```javascript
// Zustand slice
const useModuleStore = create((set, get) => ({
  modules: {
    'MOD-TIMELINE':     { state: 'dormant' },
    'MOD-FILES':        { state: 'dormant' },
    'MOD-COMMS':        { state: 'dormant' },
    'MOD-APPROVALS':    { state: 'dormant' },
    'MOD-LEADERBOARD':  { state: 'dormant' },
    'MOD-RESOURCE':     { state: 'dormant' },
  },

  deployModule: async (id) => {
    const { modules } = get();
    if (modules[id].state === 'active') return;
    
    // QUEUED
    set(s => ({ modules: { ...s.modules, [id]: { state: 'queued' } } }));
    
    await new Promise(r => setTimeout(r, 50)); // brief queue delay
    
    // DEPLOYING
    set(s => ({ modules: { ...s.modules, [id]: { state: 'deploying' } } }));
    
    // Wait for animation
    await new Promise(r => setTimeout(r, 800));
    
    // ACTIVE
    set(s => ({ modules: { ...s.modules, [id]: { state: 'active' } } }));
  },

  sleepModule: (id) => {
    set(s => ({ modules: { ...s.modules, [id]: { state: 'sleeping' } } }));
  },

  dismissModule: (id) => {
    set(s => ({ modules: { ...s.modules, [id]: { state: 'dormant' } } }));
  },
}));
```

---

## 7. Boot Sequence — Module Array Reveal

On initial load (after card insertion + boot text), deploy modules in sequence:

```javascript
async function bootModuleArray(deployFn) {
  // Primary is always visible — no animation needed
  
  // Staggered expansion (250ms between each)
  const sequence = [
    { id: 'MOD-TIMELINE', delay: 200 },
    { id: 'MOD-FILES',    delay: 450 },
    { id: 'MOD-COMMS',    delay: 700 }, // TEAM only — check role
  ];
  
  for (const { id, delay } of sequence) {
    await new Promise(r => setTimeout(r, delay));
    deployFn(id);
  }
}
```

---

## 8. Performance Contracts

### Non-negotiable rules:
1. **Only animate `transform` and `opacity`.** Never animate `width`, `height`, `top`, `left`, `margin`, `padding`.
2. **All modules use `position: absolute`** within the device canvas. No impact on document flow.
3. **`will-change: transform, opacity`** on all `.module` elements (set declaratively in CSS, not JS).
4. **No layout reads inside animation loops.** Pre-calculate all positions before animation starts.
5. **Use `requestAnimationFrame`** for any JS-driven animation frames.
6. **60fps target:** Test with Chrome DevTools Performance panel. Flag anything above 8ms frame time.

```css
/* Apply to all module elements */
.module {
  will-change: transform, opacity;
  transform: translateZ(0); /* GPU layer promotion */
  contain: layout style paint; /* isolation for perf */
}
```

### Measuring:
```javascript
// Wrap deployModule in performance measurement during dev
const start = performance.now();
await deployModule(id);
console.log(`[PERF] ${id} deploy: ${(performance.now() - start).toFixed(1)}ms`);
```

---

## 9. Sleeping Modules (Minimised State)

Modules that are deployed but not actively viewed enter SLEEPING state — partially retracted, indicator light only:

```css
.module[data-state="sleeping"] {
  /* Show just the edge with indicator light */
  --sleep-expose: 24px;
}

/* Example for left-side module (FILES) */
.mod-files[data-state="sleeping"] {
  transform: translateX(calc(-100% + var(--sleep-expose)));
  transition: transform 0.5s cubic-bezier(0.25, 0, 0, 1);
}
```

The exposed edge shows:
- Module indicator light (blinking)
- Module label (vertical text, monospace)
- Click/tap to re-deploy

---

## 10. Responsive Degradation

On viewports < 1280px, disable expansion system:

```javascript
function canExpand() {
  return window.innerWidth >= 1280;
}

// In deployModule:
if (!canExpand()) {
  // Navigate to module content in primary screen instead
  setActivePrimaryView(id);
  return;
}
```

---

## 11. React Component Pattern

```jsx
// ModuleWrapper.jsx
import { motion, AnimatePresence } from 'framer-motion';
import { useModuleStore } from '../store/modules';

const DIRECTION_VARIANTS = {
  left:  { dormant: { x: '-100%' }, active: { x: 0 } },
  right: { dormant: { x: '100%'  }, active: { x: 0 } },
  up:    { dormant: { y: '-100%' }, active: { y: 0 } },
  down:  { dormant: { y: '100%'  }, active: { y: 0 } },
};

export function ModuleWrapper({ id, direction, children, className }) {
  const state = useModuleStore(s => s.modules[id]?.state);
  const variants = DIRECTION_VARIANTS[direction];

  return (
    <AnimatePresence>
      {state !== 'dormant' && (
        <motion.div
          className={`module ${className}`}
          data-state={state}
          initial={variants.dormant}
          animate={{
            ...variants.active,
            opacity: state === 'sleeping' ? 0.4 : 1,
          }}
          exit={variants.dormant}
          transition={{
            duration: 0.7,
            ease: [0.25, 0, 0, 1],
          }}
        >
          {children}
          <ConnectorIndicator position={direction} active={state === 'active'} />
        </motion.div>
      )}
    </AnimatePresence>
  );
}
```

---
*SKILL-SCREEN-EXPANSION.md — End*
